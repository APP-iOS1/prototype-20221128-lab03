//
//  SchoolsApp.swift
//  Schools
//
//  Created by Jongwook Park on 2022/11/30.
//

import SwiftUI

@main
struct SchoolsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
